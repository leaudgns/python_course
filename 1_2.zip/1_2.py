days = ('Mon',"Tue",'Wed','Thur','Fri','Sat','Sun')
print(type(days))

nico = {'name' : 'nico', 'age' : 29, 'korean' : True, 'fav_food' : ['kimchi','sashimi']}

print(nico)
nico['handsome']=True
print(nico)