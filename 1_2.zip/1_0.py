a = "like this"
b = 3
c = True
a_number = 3
a_float = 3.12
a_none = None

print(type(a_none))