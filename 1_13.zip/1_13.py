import math

print(math.ceil(1.2))
print(math.fabs(-1.2))

from math import fsum
print(fsum([1,2,3,4,5,6,7]))

from math import fsum as sexy_sum
print(sexy_sum([1,2,3,4,5,6,7]))

from calc import plus, minus

print(plus(1,2),minus(1,2))