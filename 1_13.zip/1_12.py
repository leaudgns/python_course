days = ("Mon","Tue","Wed","Thu","Fri")

for day in days:
  if day is "Wed":
    break
  print(day)